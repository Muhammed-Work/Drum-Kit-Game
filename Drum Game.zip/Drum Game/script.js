function checkAndRun(key){
    switch(key){
            case 'w':
                new Audio(arrSoundes[0]).play();
                break;
            case "a":
                new Audio(arrSoundes[1]).play();
                break;
                
            case "s":
                new Audio(arrSoundes[2]).play();
                break;

            case "d":
                new Audio(arrSoundes[3]).play();
                break;

            case "j":
                new Audio(arrSoundes[4]).play();
                break;

            case "k":
                new Audio(arrSoundes[5]).play();
                break;

            case "l":
                new Audio(arrSoundes[6]).play();
                break;
            default:
                console.log("default");

        }
}

var c= document.querySelectorAll(".drum div");

var arrSoundes=["sounds/tom-1.mp3","sounds/tom-2.mp3","sounds/tom-3.mp3",
    "sounds/tom-4.mp3","sounds/snare.mp3","sounds/crash.mp3","sounds/kick-bass.mp3"]


    for(let i=0; i<c.length;i++ ){
        c[i].addEventListener("click",() =>runAudio(arrSoundes[i]))

    }

function runAudio(path){
    new Audio(path).play();
    console.log("something");
}



document.addEventListener("keydown",function( event ){

    console.log(event.key.toString())
    checkAndRun(event.key.toString());
}
);